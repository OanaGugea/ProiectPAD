#include<stdio.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<netinet.h>
#include<fcntl.h>
#include<string.h>

int set_addr(struct socketaddr_in *addr, char *name, u_int32_t inaddr, short sin_port){
	struct hostent *h;
	memset((void *)addr, 0, sizeof(*addr));
	addr->sin_family=AF_INET;
	

int main(void){
	struct sockaddr_in local_addr, remote_addr;
	socklen_t rlen;
	FILE *f;
	f=fopen("server.txt", "r");
	int port;
	fscanf(f,"%d", &port);
	int sockfd, connfd;
	pid_t pid;
	if((sockfd=socket(PF_INET, SOCK_STREAM,0))==-1){
		printf("Eroare la crearea soclului!\n");
		exit(1);
	}
	set_addr(&local_addr, NULL, INADDR_ANY, port);
	if((bind(sockfd, (struct sockaddr *)&local_addr, sizeof(local_addr)))==-1){
		printf("Eroare la bind()!\n");
		exit(2);
	}
	if((listen(sockfs,5))==-1){
		printf("Eroare la listen!\n");
		exit(3);
	}
	rlen=sizeof(remote_addr);
	while(1){
		connfd=accept(sockfd, (struct sockaddr *)&remote_addr, &rlen);
		if(connfd<0){
			printf("Eroare la accept()!\n");
			exit(4);
		}
		pid_t=fork();
		switch(pid){
			case -1: {
				printf("Eroare la fork()!\n");
				exit(5);
			}
			case 0: {
				close(sockfd);
				
				exit(0);
			}
			default: {
				close(connfd);
			}
		}
		exit(0);
}
	}
